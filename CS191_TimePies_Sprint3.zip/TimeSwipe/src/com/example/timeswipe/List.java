package com.example.timeswipe;

import java.util.*;

public class List {
	private static ArrayList<ListTask> tasks;
	
	public static void init(ArrayList<ListTask> arr){
		tasks = arr;
	}
	
	public static void addTask(ListTask t){
		tasks.add(t);
	}
	
	public static void delTask(int i){
		tasks.remove(i);
	}
	
	public static void editTask(String n){
		
	}
	
	public static void editTask(String d, int i){
		
	}
	
	public static ArrayList<ListTask> get(){
		return tasks;
	}
}
