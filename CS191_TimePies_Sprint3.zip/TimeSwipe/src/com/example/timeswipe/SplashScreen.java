/**
 * REVISED BSD LICENSE
 * Copyright (c) 2015, Patricia Kelly D. Co, Kenneth T. Otsuka, Mary Jane T. Rubio
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in the
      documentation and/or other materials provided with the distribution.
    * Neither the name of the <organization> nor the
      names of its contributors may be used to endorse or promote products
      derived from this software without specific prior written permission.

 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL Patricia Kelly Co, Mary Jane T. Rubio, and 
 * Kenneth T. Otsuka BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT 
 * OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS 
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY 
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * @author Patricia Kelly D. Co
 * This is a course requirement for CS 192 Software Eng'g II under the supervision of 
 * Prof. Ma. Rowena C. Solamo of the Department of Computer Science, College of Engineering, 
 * University of the Philippines, Diliman for AY 2014-2015.
 */
/**
 * Code History
 * @version 1.0
 * @author Patricia Kelly D. Co
 * @since 2014-11-24
 * Initial code.
 * @version 1.0
 * @author Patricia Kelly D. Co
 * @since 2015-02-09
 * Changed the initial splash screen to an animated splash screen.
 */
/**
 * Created on 2014-11-24
 * Developed by Purple McShortShort
 * Client Pink PlastiCS
 * Splash screen for the application.
 */

package com.example.timeswipe;

import android.app.Activity;
import android.content.Intent;
import android.graphics.drawable.AnimationDrawable;
import android.os.Bundle;
import android.widget.ImageView;
/**
 * Displays the splash screen.
 *
 */
public class SplashScreen extends Activity {	
     /**
      * onCreate
      *  - This is the onCreate method that starts up the splash screen.
      * @since 2015-02-09
      * @param savedInstanceState Saves the state upon call
      * @return void
      * @exception InterruptedException
      */
	 @Override 
     protected void onCreate(Bundle savedInstanceState){
          super.onCreate(savedInstanceState);
          setContentView(R.layout.splash);
          
          ImageView splashView = (ImageView)findViewById(R.id.splashScreen);
          splashView.setBackgroundResource(R.drawable.splashscreen_gif);
          
          AnimationDrawable splashGif = (AnimationDrawable)splashView.getBackground();
          
          splashGif.start();
          
          Thread logoTimer = new Thread(){
        	  @Override
               public void run(){
                   
                    try {
                         int logoTimer = 0;
                         while(logoTimer < 3000){
                              sleep(100);
                              logoTimer = logoTimer + 100;
                         }
                         startActivity(new Intent("com.example.CLEARSCREEN"));
                    }catch (InterruptedException e){
                         e.printStackTrace();
                    }finally {
                         finish();
                    }
               }
          };
          logoTimer.start();
     }
}