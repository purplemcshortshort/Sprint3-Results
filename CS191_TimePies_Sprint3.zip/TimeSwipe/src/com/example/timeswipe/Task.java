/**
 * REVISED BSD LICENSE
 * Copyright (c) 2015, Patricia Kelly D. Co, Kenneth T. Otsuka, Mary Jane T. Rubio
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in the
      documentation and/or other materials provided with the distribution.
    * Neither the name of the <organization> nor the
      names of its contributors may be used to endorse or promote products
      derived from this software without specific prior written permission.

 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL Patricia Kelly Co, Mary Jane T. Rubio, and 
 * Kenneth T. Otsuka BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT 
 * OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS 
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY 
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * @author Mary Jane T. Rubio
 * This is a course requirement for CS 192 Software Eng'g II under the supervision of 
 * Prof. Ma. Rowena C. Solamo of the Department of Computer Science, College of Engineering, 
 * University of the Philippines, Diliman for AY 2014-2015.
 */
/**
 * Code History
 * @version 1.0
 * @author Mary Jane T. Rubio
 * @since 2014-11-20
 * Initial code.
 * @version 1.1
 * @author Mary Jane T. RUbio
 * @since 2015-02-16
 * Added constructor Task(String)
 */
/**
 * Created on 2014-11-20
 * Developed by Purple McShortShort
 * Client Pink PlastiCS
 * Model of a task.
 */
package com.example.timeswipe;

/**
 * Stores a task's name and date.
 *
 */
public class Task{
     private String name;
     private String date;
     
     /**
      * Task
      *  - Task constructor. Sets only the task's name.
      * @param n Name of task (String)
      */
     public Task(String n){
    	 this.name = n;
     }
     
     /**
      * Task 
      *  - Task constructor. Sets the task's name and date.
      * @since 2014-11-20
      * @param n Name of the task (String)
      * @param d Date of the task (String)
      * @return void
      */
     public Task(String n, String d){
          this.name = n;
          this.date = d;
     }
     
     /**
      * getDate
      *  - Returns the task's date.
      * @since 2014-11-20
      * @param void
      * @return date 
      */
     public String getDate(){
          return date;
     }
     
     /**
      * getName
      *  - Returns task's name.
      * @since 2014-11-20
      * @param void
      * @return name
      */
     public String getName(){
          return name;
     }
     
     /**
      * setDate
      *  - Sets task's date.
      * @since 2014-11-20
      * @param d Date of task (String)
      * @return void
      */
     public void setDate(String d){
          date = d;
     }
     
     /**
      * setName
      *  - Sets task's name.
      * @since 2014-11-20
      * @param n Name of task (String)
      * @return void
      */
     public void setName(String n){
          name = n;
     }
}